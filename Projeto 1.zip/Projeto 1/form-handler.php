<?php
$name = $_POST['nome'];
$visitor_email = $_POST['email'];
$subject = $POST['subject'];
$message = $POST['message'];

$email_from = 'rafael.santos@pditabira.com';

$email_subject = 'Você Recebeu Uma message Via Site';

$email_body = "Nome do Usuário:$name.\n".
              "Email do Usuário: $visitor_email.\n".
              "subject: $subject.\n".
                "message do Usuário:$$message.\n";


$to = 'igordumont.smart@gmail.com';

$headers = "De: $email_from \r\n";

$headers = "Responder: $visitor_email \r\n";


mail($to,$email_subject,$email_body,$headers);

header("Location: contato.html");
?>